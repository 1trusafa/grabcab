import Constants from 'expo-constants';

export const cloud_function_server_url = Constants.manifest.extra.cloud_function_server_url;
import Constants from 'expo-constants';

export const google_map_key = Constants.manifest.extra.googlemapkey;